package projeto.maispop.midia;

public class MensagemString implements Postavel{

	@Override
	public String getConteudo() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setConteudo(String conteudo) {
		// TODO Auto-generated method stub
		
	}


	
}
