package projeto.maispop.midia;

public interface Postavel {

	public String getConteudo();
	public void setConteudo(String conteudo);

}
